import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import apriltag

class AprilTagDetectionNode(Node):
    def __init__(self):
        super().__init__('apriltag_detection_node')
        self.subscription = self.create_subscription(
            Image,
            '/camera/color/image_raw',  # The camera topic
            self.listener_callback,
            10
        )
        self.bridge = CvBridge()
        self.detector = apriltag.Detector()

    def listener_callback(self, msg):
        # Convert ROS Image message to OpenCV image
        cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

        # Convert to grayscale for AprilTag detection
        gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

        # Detect AprilTags
        results = self.detector.detect(gray)

        for result in results:
            self.get_logger().info(f'Detected AprilTag ID: {result.tag_id}')
            # You can add additional logic to control your robot based on tag position, etc.

def main(args=None):
    rclpy.init(args=args)
    node = AprilTagDetectionNode()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
