from setuptools import find_packages, setup

package_name = 'apriltag_detection'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=[
        'setuptools',     # Package setup tool
        'cv_bridge',      # ROS2 image conversion package
        'apriltag',       # Package for AprilTag detection
        'rclpy',          # ROS2 Python library
    ],
    zip_safe=True,
    maintainer='rm3010',
    maintainer_email='rm3010@todo.todo',
    description='AprilTag detection for robotics',
    license='MIT',  # Replace with the appropriate license
    extras_require={
        'test': [
            'pytest',  # For testing your ROS 2 nodes
        ],
    },
    entry_points={
        'console_scripts': [
            'apriltag_detection_node = apriltag_detection.apriltag_detection_node:main',  # Define the ROS 2 node entry point
        ],
    },
)

