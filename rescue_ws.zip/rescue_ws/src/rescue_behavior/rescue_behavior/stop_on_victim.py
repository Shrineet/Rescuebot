import rclpy
from rclpy.node import Node

from std_msgs.msg import Bool
from geometry_msgs.msg import Twist


class StopOnVictim(Node):
    def __init__(self):
        super().__init__('stop_on_victim')

        # Subscribe to victim flag
        self.sub = self.create_subscription(
            Bool,
            '/rescue/victim_detected',
            self.cb_victim,
            10
        )

        # Publish velocity commands
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.victim = False

        # Publish stop cmd repeatedly when victim is true
        self.timer = self.create_timer(0.1, self.tick)  # 10 Hz

        self.get_logger().info("StopOnVictim running: stops robot when /rescue/victim_detected is True")

    def cb_victim(self, msg: Bool):
        self.victim = bool(msg.data)

    def tick(self):
        if not self.victim:
            return

        # Keep publishing stop to override wander
        t = Twist()
        t.linear.x = 0.0
        t.linear.y = 0.0
        t.linear.z = 0.0
        t.angular.x = 0.0
        t.angular.y = 0.0
        t.angular.z = 0.0
        self.cmd_pub.publish(t)


def main(args=None):
    rclpy.init(args=args)
    node = StopOnVictim()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
