import math
import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan


class Wander(Node):
    def __init__(self):
        super().__init__('wander')

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.sub_scan = self.create_subscription(LaserScan, '/scan', self.cb_scan, 10)

        self.front_min = None
        self.left_min = None
        self.right_min = None

        # Speeds (stable)
        self.forward_speed = 0.04
        self.turn_speed = 0.4

        self.timer = self.create_timer(0.1, self.tick)  # 10 Hz
        self.get_logger().info("Wander running (wrap-around front): publishes /cmd_vel using /scan")

    def cb_scan(self, msg: LaserScan):
        n = len(msg.ranges)
        if n == 0:
            return

        def clean_min(vals):
            valid = [
                r for r in vals
                if msg.range_min < r < msg.range_max and not math.isinf(r) and not math.isnan(r)
            ]
            return min(valid) if valid else None

        # Your scan: angle_min=0.0, angle_max~2π
        # front is around 0 rad AND wrap-around at end of ranges[]
        k = 20  # ~20*0.0175 = 0.35 rad (~20 degrees)
        front_vals = list(msg.ranges[0:k]) + list(msg.ranges[-k:])

        # left around +90 deg (pi/2)
        i_left = int((1.5708 - msg.angle_min) / msg.angle_increment)
        left_vals = msg.ranges[max(0, i_left - 30): min(n, i_left + 30)]

        # right around 270 deg (3pi/2)
        i_right = int((4.7124 - msg.angle_min) / msg.angle_increment)
        right_vals = msg.ranges[max(0, i_right - 30): min(n, i_right + 30)]

        self.front_min = clean_min(front_vals)
        self.left_min = clean_min(left_vals)
        self.right_min = clean_min(right_vals)

    def tick(self):
        t = Twist()

        # wait for scan
        if self.front_min is None:
            self.cmd_pub.publish(t)
            return

        # thresholds
        front_block = 0.65
        side_block = 0.50

        # If something close in front: turn away
        if self.front_min < front_block:
            t.linear.x = 0.0
            if self.left_min is not None and self.right_min is not None:
                # turn away from closer side
                t.angular.z = -self.turn_speed if self.left_min < self.right_min else self.turn_speed
            else:
                t.angular.z = self.turn_speed
            self.cmd_pub.publish(t)
            return

        # Wall avoidance
        if self.left_min is not None and self.left_min < side_block:
            t.linear.x = 0.04
            t.angular.z = -0.5
        elif self.right_min is not None and self.right_min < side_block:
            t.linear.x = 0.04
            t.angular.z = 0.5
        else:
            # cruise
            t.linear.x = self.forward_speed
            t.angular.z = 0.0

        self.cmd_pub.publish(t)


def main(args=None):
    rclpy.init(args=args)
    node = Wander()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
