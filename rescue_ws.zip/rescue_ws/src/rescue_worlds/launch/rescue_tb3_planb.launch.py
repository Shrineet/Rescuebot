import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    x = LaunchConfiguration('x')
    y = LaunchConfiguration('y')
    z = LaunchConfiguration('z')

    pkg_rescue = get_package_share_directory('rescue_worlds')
    world = os.path.join(pkg_rescue, 'worlds', 'rescue_world.world')

    pkg_gazebo_ros = get_package_share_directory('gazebo_ros')
    gazebo_launch = os.path.join(pkg_gazebo_ros, 'launch', 'gazebo.launch.py')

    # TurtleBot3 Gazebo models path (SDF)
    pkg_tb3_gazebo = get_package_share_directory('turtlebot3_gazebo')

    # CHANGE this if your find command shows a different model folder name
    tb3_model_sdf = os.path.join(
        pkg_tb3_gazebo, 'models', 'turtlebot3_waffle_pi', 'model.sdf'
    )

    return LaunchDescription([
        DeclareLaunchArgument('x', default_value='0.0', description='Spawn x'),
        DeclareLaunchArgument('y', default_value='0.0', description='Spawn y'),
        DeclareLaunchArgument('z', default_value='0.01', description='Spawn z'),

        # Don't download models from internet
        SetEnvironmentVariable(name='GAZEBO_MODEL_DATABASE_URI', value=''),

        # Add both your models + turtlebot3 models so gazebo can find them
        SetEnvironmentVariable(
            name='GAZEBO_MODEL_PATH',
            value=':'.join([
                os.path.join(pkg_rescue, 'models'),
                os.path.join(pkg_tb3_gazebo, 'models')
            ])
        ),

        # 1) Start Gazebo with your world
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(gazebo_launch),
            launch_arguments={'world': world}.items()
        ),

        # 2) Spawn TurtleBot3 from SDF file (no xacro needed)
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            output='screen',
            arguments=[
                '-entity', 'tb3',
                '-file', tb3_model_sdf,
                '-x', x,
                '-y', y,
                '-z', z
            ],
        ),
    ])
