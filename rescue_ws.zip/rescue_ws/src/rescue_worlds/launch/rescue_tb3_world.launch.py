import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource


def generate_launch_description():
    pkg_tb3 = get_package_share_directory('turtlebot3_gazebo')
    pkg_rescue = get_package_share_directory('rescue_worlds')

    world = os.path.join(pkg_rescue, 'worlds', 'rescue_world.world')
    tb3_launch = os.path.join(pkg_tb3, 'launch', 'turtlebot3_world.launch.py')

    return LaunchDescription([
        # Avoid Gazebo trying to download models from internet
        SetEnvironmentVariable(name='GAZEBO_MODEL_DATABASE_URI', value=''),

        # Let Gazebo find your custom models folder (optional)
        SetEnvironmentVariable(name='GAZEBO_MODEL_PATH', value=os.path.join(pkg_rescue, 'models')),

        # Launch TurtleBot3 world launch, but with OUR world file
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(tb3_launch),
            launch_arguments={'world': world}.items()
        ),
    ])
