import rclpy
from rclpy.node import Node

from sensor_msgs.msg import Image
from cv_bridge import CvBridge

from std_msgs.msg import Bool
from geometry_msgs.msg import PoseStamped
from tf2_ros import Buffer, TransformListener

import cv2
import numpy as np
from ultralytics import YOLO


class RescueYoloNode(Node):
    def __init__(self):
        super().__init__('rescue_yolo_node')

        # Parameters
        self.declare_parameter('image_topic', '/camera/image_raw')
        self.declare_parameter('model', 'yolov8n.pt')
        self.declare_parameter('conf', 0.5)

        image_topic = self.get_parameter('image_topic').get_parameter_value().string_value
        model_name = self.get_parameter('model').get_parameter_value().string_value
        self.conf = float(self.get_parameter('conf').get_parameter_value().double_value)

        self.bridge = CvBridge()
        self.model = YOLO(model_name)

        self.sub = self.create_subscription(Image, image_topic, self.cb_image, 10)
        self.pub_debug = self.create_publisher(Image, '/yolo/debug_image', 10)

        self.pub_victim = self.create_publisher(Bool, '/rescue/victim_detected', 10)
        self.pub_pose = self.create_publisher(PoseStamped, '/rescue/victim_pose', 10)

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.last_report_time = self.get_clock().now()
        self.report_cooldown_sec = 3.0

        self.get_logger().info(f"YOLO ready. Subscribing to: {image_topic}")
        self.get_logger().info("Publishing debug images to: /yolo/debug_image")

    def cb_image(self, msg: Image):
        # ROS -> OpenCV
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        annotated = frame.copy()

        # Always-visible watermark to confirm you are seeing annotated output
        cv2.putText(
            annotated,
            "DEBUG: annotated OK",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            1.0,
            (0, 0, 255),
            2
        )

        # =========================================================
        # Victim detection via COLOR + SHAPE (Gazebo-safe)
        # Victim = light/grey cylinder-like object
        # =========================================================
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Light/grey objects: low saturation + reasonably bright
        lower_obj = np.array([0, 0, 90])       # V>=90 catches grey + white
        upper_obj = np.array([180, 80, 255])   # S<=80 avoids green walls
        mask = cv2.inRange(hsv, lower_obj, upper_obj)

        # Clean mask
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        # Show mask preview in top-left corner (debug)
        mask_bgr = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
        h, w = annotated.shape[:2]
        small = cv2.resize(mask_bgr, (w // 3, h // 3))
        annotated[0:small.shape[0], 0:small.shape[1]] = small

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        cv_victim_detected = False
        victim_bbox = None

        for cnt in contours:
            x, y, bw, bh = cv2.boundingRect(cnt)
            area = cv2.contourArea(cnt)

            # Make detection permissive for Gazebo cylinders
            if area > 200 and bh > bw * 1.1:
                cv_victim_detected = True
                victim_bbox = (x, y, bw, bh)
                break

        if cv_victim_detected and victim_bbox is not None:
            x, y, bw, bh = victim_bbox
            cv2.rectangle(annotated, (x, y), (x + bw, y + bh), (255, 0, 0), 2)
            cv2.putText(
                annotated,
                "VICTIM",
                (x, max(20, y - 10)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                (255, 0, 0),
                2
            )

        # =========================================================
        # YOLO inference (kept for AI requirement)
        # =========================================================
        try:
            results = self.model.predict(source=frame, conf=self.conf, verbose=False)
            for r in results:
                if r.boxes is None:
                    continue
                names = r.names
                for b in r.boxes:
                    cls_id = int(b.cls[0].item())
                    cls_name = str(names.get(cls_id, cls_id))
                    conf = float(b.conf[0].item())
                    x1, y1, x2, y2 = [int(v.item()) for v in b.xyxy[0]]

                    cv2.rectangle(annotated, (x1, y1), (x2, y2), (0, 255, 0), 1)
                    cv2.putText(
                        annotated,
                        f"{cls_name} {conf:.2f}",
                        (x1, max(20, y1 - 5)),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,
                        (0, 255, 0),
                        1
                    )
        except Exception as e:
            self.get_logger().warn(f"YOLO inference failed (continuing with CV victim detection): {e}")

        # =========================================================
        # Publish victim event + pose (throttled)
        # =========================================================
        now = self.get_clock().now()

        if cv_victim_detected:
            self.pub_victim.publish(Bool(data=True))

            if (now - self.last_report_time).nanoseconds > int(self.report_cooldown_sec * 1e9):
                try:
                    tf = self.tf_buffer.lookup_transform('odom', 'base_link', rclpy.time.Time())

                    pose = PoseStamped()
                    pose.header.stamp = now.to_msg()
                    pose.header.frame_id = 'odom'
                    pose.pose.position.x = tf.transform.translation.x
                    pose.pose.position.y = tf.transform.translation.y
                    pose.pose.position.z = tf.transform.translation.z
                    pose.pose.orientation = tf.transform.rotation

                    self.pub_pose.publish(pose)
                    self.get_logger().info(
                        f"Victim pose published: x={pose.pose.position.x:.2f}, y={pose.pose.position.y:.2f}"
                    )
                    self.last_report_time = now
                except Exception as e:
                    self.get_logger().warn(f"TF lookup failed: {e}")
        else:
            self.pub_victim.publish(Bool(data=False))

        # Publish debug image
        out = self.bridge.cv2_to_imgmsg(annotated, encoding='bgr8')
        out.header = msg.header
        self.pub_debug.publish(out)


def main(args=None):
    rclpy.init(args=args)
    node = RescueYoloNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
